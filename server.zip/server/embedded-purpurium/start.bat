@echo off
java -jar embedded-purpurium-1.0.0.jar