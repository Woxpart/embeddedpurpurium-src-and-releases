package net.embpurpurium.api.scheduler;

import net.embpurpurium.plugin.JavaPlugin;

import java.util.concurrent.ScheduledFuture;

public class ScheduledTask {
    private final int id;
    private final JavaPlugin owner;
    private final ScheduledFuture<?> future;
    private final boolean repeating;
    private boolean cancelled = false;

    public ScheduledTask(int id, JavaPlugin owner, ScheduledFuture<?> future, boolean repeating) {
        this.id = id; this.owner = owner; this.future = future; this.repeating = repeating;
    }

    public void cancel() {
        if (!cancelled) { future.cancel(false); cancelled = true; }
    }

    public boolean isCancelled() { return cancelled || future.isCancelled(); }
    public boolean isDone()      { return future.isDone(); }
    public boolean isRepeating() { return repeating; }
    public int getId()           { return id; }
    public JavaPlugin getOwner() { return owner; }

    @Override
    public String toString() {
        return "ScheduledTask{id=" + id + ", owner=" + owner.getDescription().getName() + ", repeating=" + repeating + ", cancelled=" + cancelled + "}";
    }
}
