package net.embpurpurium.api.event;

public class ConsoleCommandEvent extends Event implements Cancellable {
    private String command;
    private boolean cancelled = false;

    public ConsoleCommandEvent(String command) { this.command = command; }
    public String getCommand() { return command; }
    public void setCommand(String command) { this.command = command; }

    @Override
    public boolean isCancelled() { return cancelled; }
    @Override
    public void setCancelled(boolean cancelled) { this.cancelled = cancelled; }
}
