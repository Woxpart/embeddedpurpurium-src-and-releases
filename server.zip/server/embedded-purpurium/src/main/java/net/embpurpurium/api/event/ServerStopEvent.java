package net.embpurpurium.api.event;

public class ServerStopEvent extends Event {
    public ServerStopEvent() { super(); }
}
