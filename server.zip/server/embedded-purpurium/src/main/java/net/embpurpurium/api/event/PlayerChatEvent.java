package net.embpurpurium.api.event;

public class PlayerChatEvent extends Event implements Cancellable {
    private final String playerName;
    private String message;
    private boolean cancelled = false;

    public PlayerChatEvent(String playerName, String message) {
        this.playerName = playerName; this.message = message;
    }
    public String getPlayerName() { return playerName; }
    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }

    @Override
    public boolean isCancelled() { return cancelled; }
    @Override
    public void setCancelled(boolean cancelled) { this.cancelled = cancelled; }
}
