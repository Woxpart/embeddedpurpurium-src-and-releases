package net.embpurpurium.api.event;

import net.embpurpurium.console.EmbLogger;

import java.lang.reflect.Method;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

public class EventBus {
    private final EmbLogger logger = new EmbLogger("EventBus");
    private final Map<Class<? extends Event>, List<HandlerEntry>> handlers = new ConcurrentHashMap<>();

    public void registerListener(Listener listener, Object owner) {
        for (Method method : listener.getClass().getDeclaredMethods()) {
            EventHandler annotation = method.getAnnotation(EventHandler.class);
            if (annotation == null) continue;
            Class<?>[] params = method.getParameterTypes();
            if (params.length != 1 || !Event.class.isAssignableFrom(params[0])) {
                logger.warn("Method " + method.getName() + " wrong signature. Skipping.");
                continue;
            }
            @SuppressWarnings("unchecked")
            Class<? extends Event> eventType = (Class<? extends Event>) params[0];
            method.setAccessible(true);
            HandlerEntry entry = new HandlerEntry(listener, method, annotation.priority(), annotation.ignoreCancelled(), owner);
            handlers.computeIfAbsent(eventType, k -> new CopyOnWriteArrayList<>()).add(entry);
            handlers.get(eventType).sort(Comparator.comparingInt(e -> e.priority().ordinal()));
            logger.debug("Registered handler: " + listener.getClass().getSimpleName() + "#" + method.getName());
        }
    }

    public void unregisterAll(Object owner) {
        handlers.forEach((type, list) -> list.removeIf(entry -> entry.owner() == owner));
    }

    public <T extends Event> T fire(T event) {
        List<HandlerEntry> entries = handlers.get(event.getClass());
        if (entries == null || entries.isEmpty()) return event;
        boolean cancellable = event instanceof Cancellable;
        for (HandlerEntry entry : entries) {
            if (cancellable && ((Cancellable) event).isCancelled() && !entry.ignoreCancelled()) continue;
            try { entry.method().invoke(entry.listener(), event); }
            catch (Exception e) { logger.error("Exception in event handler", e); }
        }
        return event;
    }

    private record HandlerEntry(Listener listener, Method method, EventPriority priority, boolean ignoreCancelled, Object owner) {}
}
