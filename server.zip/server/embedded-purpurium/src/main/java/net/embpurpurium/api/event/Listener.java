package net.embpurpurium.api.event;

public interface Listener {
}
