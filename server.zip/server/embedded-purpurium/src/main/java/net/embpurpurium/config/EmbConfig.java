package net.embpurpurium.config;

import net.embpurpurium.console.EmbLogger;

import java.io.*;
import java.util.Properties;

public class EmbConfig {
    private static final EmbLogger logger = new EmbLogger("Config");
    private static final String CONFIG_FILE = "embpurpurium.properties";

    private static final String DEFAULT_CONFIG = """
            # =====================================================
            #  Embedded Purpurium - Configuration
            #  Supports Minecraft 1.13.2 - 1.21.4
            # =====================================================

            # Minecraft server version to download & run
            # Any version from 1.13.2 up to 1.21.4 is supported
            server.version=1.21.4

            # JVM Memory
            server.memory.min=512M
            server.memory.max=2G

            # Extra JVM Args
            server.extra.args=

            # Console
            console.colors=true
            console.show.server.output=true

            # Plugins
            plugin.load.order=alphabetical
            """;

    private final Properties props = new Properties();

    public EmbConfig() { load(); }

    private void load() {
        File file = new File(CONFIG_FILE);
        if (!file.exists()) {
            try (PrintWriter pw = new PrintWriter(new FileWriter(file))) {
                pw.print(DEFAULT_CONFIG);
                logger.info("Created default config: " + CONFIG_FILE);
            } catch (IOException e) { logger.error("Failed to write default config", e); }
        }
        try (InputStream is = new FileInputStream(file)) {
            props.load(is);
            logger.success("Loaded config: " + CONFIG_FILE);
        } catch (IOException e) { logger.error("Failed to load config, using defaults", e); }
    }

    public String get(String key, String defaultValue) { return props.getProperty(key, defaultValue); }
    public boolean getBoolean(String key, boolean defaultValue) {
        String val = props.getProperty(key);
        return val != null ? Boolean.parseBoolean(val.trim()) : defaultValue;
    }

    public String serverVersion() { return get("server.version", "1.21.4").trim(); }
    public String minMemory()      { return get("server.memory.min", "512M"); }
    public String maxMemory()      { return get("server.memory.max", "2G"); }
    public String extraArgs()      { return get("server.extra.args", ""); }
    public boolean showServerOutput() { return getBoolean("console.show.server.output", true); }
    public String pluginLoadOrder()   { return get("plugin.load.order", "alphabetical"); }
}
