package net.embpurpurium.plugin;

import com.google.gson.Gson;
import net.embpurpurium.console.EmbLogger;

import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.charset.StandardCharsets;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

public class PluginLoader {
    private static final EmbLogger logger = new EmbLogger("PluginLoader");
    private static final Gson GSON = new Gson();

    public JavaPlugin load(File file, PluginManager manager) {
        if (!file.getName().endsWith(".embplugin")) {
            logger.warn("Skipping non-.embplugin file: " + file.getName());
            return null;
        }
        try (ZipFile zip = new ZipFile(file)) {
            ZipEntry metaEntry = zip.getEntry("embplugin.json");
            if (metaEntry == null) {
                logger.error("Missing embplugin.json in: " + file.getName());
                return null;
            }
            PluginDescription desc;
            try (InputStream is = zip.getInputStream(metaEntry);
                 InputStreamReader reader = new InputStreamReader(is, StandardCharsets.UTF_8)) {
                desc = GSON.fromJson(reader, PluginDescription.class);
            }
            desc.validate();
            URLClassLoader classLoader = new URLClassLoader(
                    new URL[]{file.toURI().toURL()}, JavaPlugin.class.getClassLoader());
            Class<?> rawClass = classLoader.loadClass(desc.getMain());
            if (!JavaPlugin.class.isAssignableFrom(rawClass)) {
                logger.error("Main class " + desc.getMain() + " does not extend JavaPlugin!");
                classLoader.close();
                return null;
            }
            JavaPlugin plugin = (JavaPlugin) rawClass.getDeclaredConstructor().newInstance();
            plugin.setDescription(desc);
            plugin.setPluginManager(manager);
            logger.success("Loaded plugin: " + desc);
            return plugin;
        } catch (Exception e) {
            logger.error("Failed to load plugin: " + file.getName(), e);
            return null;
        }
    }
}
