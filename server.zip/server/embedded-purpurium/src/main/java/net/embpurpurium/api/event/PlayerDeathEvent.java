package net.embpurpurium.api.event;

public class PlayerDeathEvent extends Event {
    private final String playerName;
    private final String deathMessage;

    public PlayerDeathEvent(String playerName, String deathMessage) {
        this.playerName = playerName; this.deathMessage = deathMessage;
    }
    public String getPlayerName() { return playerName; }
    public String getDeathMessage() { return deathMessage; }
}
