package net.embpurpurium.api.event;

public class PlayerJoinEvent extends Event {
    private final String playerName;
    private String joinMessage;

    public PlayerJoinEvent(String playerName) {
        this.playerName = playerName;
        this.joinMessage = playerName + " joined the game";
    }
    public String getPlayerName() { return playerName; }
    public String getJoinMessage() { return joinMessage; }
    public void setJoinMessage(String joinMessage) { this.joinMessage = joinMessage; }
}
