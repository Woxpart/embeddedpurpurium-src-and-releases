package net.embpurpurium.server;

import net.embpurpurium.console.EmbLogger;

import java.io.*;
import java.net.*;
import java.security.*;

public class ServerDownloader {
    private static final EmbLogger logger = new EmbLogger("Downloader");
    private static final String MANIFEST_URL =
            "https://launchermeta.mojang.com/mc/game/version_manifest_v2.json";

    private final String targetVersion;

    public ServerDownloader(String version) {
        this.targetVersion = version;
    }

    public void download(File destination) throws Exception {
        destination.getParentFile().mkdirs();
        EmbLogger.separator();
        logger.info("Fetching version manifest from Mojang CDN...");
        String manifest = fetchString(MANIFEST_URL);
        String versionUrl = extractVersionUrl(manifest, targetVersion);
        if (versionUrl == null) {
            throw new RuntimeException("Minecraft " + targetVersion + " not found in Mojang manifest!");
        }
        logger.info("Fetching metadata for Minecraft " + targetVersion + "...");
        String versionJson = fetchString(versionUrl);
        String serverUrl  = extractServerUrl(versionJson);
        String serverSha1 = extractServerSha1(versionJson);
        long   serverSize = extractServerSize(versionJson);

        if (serverUrl == null) {
            throw new RuntimeException("No server JAR download found for " + targetVersion +
                    ". This version may not have a standalone server release.");
        }

        logger.info("Downloading server.jar - " + EmbLogger.YELLOW + (serverSize / 1_048_576) + " MB" + EmbLogger.RESET + " from Mojang...");
        downloadWithProgress(serverUrl, destination, serverSize);
        logger.info("Verifying SHA-1 checksum...");
        String actualSha1 = sha1(destination);
        if (!actualSha1.equalsIgnoreCase(serverSha1)) {
            destination.delete();
            throw new RuntimeException("SHA-1 mismatch!\n  Expected: " + serverSha1 + "\n  Got: " + actualSha1);
        }
        logger.success("Download verified -  " + destination.getPath());
        EmbLogger.separator();
    }

    private String extractVersionUrl(String manifest, String version) {
        int idx = manifest.indexOf("\"id\": \"" + version + "\"");
        if (idx < 0) idx = manifest.indexOf("\"id\":\"" + version + "\"");
        if (idx < 0) return null;
        int urlIdx = manifest.indexOf("\"url\":", idx);
        return extractJsonString(manifest, urlIdx + 6);
    }

    private String extractServerUrl(String json) {
        int serverIdx = json.indexOf("\"server\":");
        if (serverIdx < 0) return null;
        int urlIdx = json.indexOf("\"url\":", serverIdx);
        if (urlIdx < 0) return null;
        return extractJsonString(json, urlIdx + 6);
    }

    private String extractServerSha1(String json) {
        int serverIdx = json.indexOf("\"server\":");
        if (serverIdx < 0) return null;
        int sha1Idx = json.indexOf("\"sha1\":", serverIdx);
        if (sha1Idx < 0) return null;
        return extractJsonString(json, sha1Idx + 7);
    }

    private long extractServerSize(String json) {
        int serverIdx = json.indexOf("\"server\":");
        if (serverIdx < 0) return -1;
        int sizeIdx = json.indexOf("\"size\":", serverIdx);
        if (sizeIdx < 0) return -1;
        int start = sizeIdx + 7;
        while (start < json.length() && !Character.isDigit(json.charAt(start))) start++;
        int end = start;
        while (end < json.length() && Character.isDigit(json.charAt(end))) end++;
        try { return Long.parseLong(json.substring(start, end)); }
        catch (NumberFormatException e) { return -1; }
    }

    private String extractJsonString(String json, int offset) {
        int start = json.indexOf('"', offset);
        if (start < 0) return null;
        int end = json.indexOf('"', ++start);
        return end < 0 ? null : json.substring(start, end);
    }

    private String fetchString(String url) throws IOException {
        HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
        conn.setConnectTimeout(15_000);
        conn.setReadTimeout(30_000);
        conn.setRequestProperty("User-Agent", "EmbeddedPurpurium/1.0");
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()))) {
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) sb.append(line).append('\n');
            return sb.toString();
        }
    }

    private void downloadWithProgress(String url, File dest, long expectedSize) throws IOException {
        HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
        conn.setConnectTimeout(15_000);
        conn.setReadTimeout(120_000);
        conn.setRequestProperty("User-Agent", "EmbeddedPurpurium/1.0");
        try (InputStream is = new BufferedInputStream(conn.getInputStream());
             FileOutputStream fos = new FileOutputStream(dest)) {
            byte[] buf = new byte[8192];
            long downloaded = 0;
            int lastRenderedPct = -1;
            int read;
            while ((read = is.read(buf)) != -1) {
                fos.write(buf, 0, read);
                downloaded += read;
                if (expectedSize > 0) {
                    int pct = (int) (downloaded * 100 / expectedSize);
                    if (pct != lastRenderedPct) {
                        renderProgressBar(pct, downloaded, expectedSize);
                        lastRenderedPct = pct;
                    }
                }
            }
            System.out.println();
        }
    }

    private void renderProgressBar(int pct, long downloaded, long total) {
        int barWidth = 40;
        int filled = (int) (barWidth * pct / 100.0);
        String bar = EmbLogger.CYAN + "\u2588".repeat(filled) + EmbLogger.GRAY + "\u2591".repeat(barWidth - filled) + EmbLogger.RESET;
        String line = String.format("  %s[%s%s] %3d%%  %s%.1f / %.1f MB%s",
                EmbLogger.GRAY, bar, EmbLogger.GRAY, pct, EmbLogger.YELLOW,
                downloaded / 1_048_576.0, total / 1_048_576.0, EmbLogger.RESET);
        System.out.print("\r" + line);
    }

    private String sha1(File file) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-1");
        try (InputStream is = new BufferedInputStream(new FileInputStream(file))) {
            byte[] buf = new byte[8192];
            int read;
            while ((read = is.read(buf)) != -1) digest.update(buf, 0, read);
        }
        StringBuilder sb = new StringBuilder();
        for (byte b : digest.digest()) sb.append(String.format("%02x", b));
        return sb.toString();
    }
}
