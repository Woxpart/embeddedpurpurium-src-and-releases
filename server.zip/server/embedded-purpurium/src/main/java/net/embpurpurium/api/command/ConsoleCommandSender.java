package net.embpurpurium.api.command;

/** Sunucu konsolunu temsil eden tekil (singleton) CommandSender. */
public final class ConsoleCommandSender implements CommandSender {

    public static final ConsoleCommandSender INSTANCE = new ConsoleCommandSender();

    private ConsoleCommandSender() {}

    @Override
    public void sendMessage(String message) {
        // Konsolda ANSI renk kodlari zaten dogru calisir, oldugu gibi basiyoruz.
        System.out.println(message);
    }

    @Override
    public String getName() { return "CONSOLE"; }

    @Override
    public boolean isPlayer() { return false; }
}
