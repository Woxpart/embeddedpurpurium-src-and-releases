package net.embpurpurium.plugin;

import java.util.List;

public class PluginDescription {
    private String name;
    private String version;
    private String main;
    private String author;
    private String description;
    private List<String> dependencies;

    public PluginDescription() {}

    public PluginDescription(String name, String version, String main,
                              String author, String description,
                              List<String> dependencies) {
        this.name = name; this.version = version; this.main = main;
        this.author = author; this.description = description;
        this.dependencies = dependencies != null ? dependencies : List.of();
    }

    public String getName() { return name; }
    public String getVersion() { return version; }
    public String getMain() { return main; }
    public String getAuthor() { return author; }
    public String getDescription() { return description; }
    public List<String> getDependencies() { return dependencies != null ? dependencies : List.of(); }

    public void validate() {
        if (name == null || name.isBlank())
            throw new IllegalStateException("Plugin 'name' is missing in embplugin.json");
        if (version == null || version.isBlank())
            throw new IllegalStateException("Plugin 'version' is missing in embplugin.json");
        if (main == null || main.isBlank())
            throw new IllegalStateException("Plugin 'main' class is missing in embplugin.json");
    }

    @Override
    public String toString() { return name + " v" + version + " by " + author; }
}
