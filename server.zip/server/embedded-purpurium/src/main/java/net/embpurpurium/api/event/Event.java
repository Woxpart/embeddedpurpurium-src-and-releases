package net.embpurpurium.api.event;

public abstract class Event {
    private final String name;
    private final long timestamp;

    public Event() {
        this.name = getClass().getSimpleName();
        this.timestamp = System.currentTimeMillis();
    }

    public String getEventName() { return name; }
    public long getTimestamp() { return timestamp; }

    @Override
    public String toString() { return "Event{name='" + name + "', timestamp=" + timestamp + "}"; }
}
