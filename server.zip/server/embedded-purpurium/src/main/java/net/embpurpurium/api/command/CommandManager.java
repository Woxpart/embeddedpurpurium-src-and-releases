package net.embpurpurium.api.command;

import net.embpurpurium.console.EmbLogger;

import java.util.*;

public class CommandManager {
    private final EmbLogger logger = new EmbLogger("CommandManager");
    private final Map<String, CommandEntry> commands = new LinkedHashMap<>();

    public CommandManager() {}

    public void registerCommand(String name, Command command, Object owner) {
        String key = name.toLowerCase(Locale.ROOT);
        if (commands.containsKey(key)) logger.warn("Command '" + key + "' already registered. Overwriting.");
        commands.put(key, new CommandEntry(command, owner));
        logger.debug("Registered command: /" + key);
    }

    public void unregisterAll(Object owner) {
        commands.entrySet().removeIf(e -> e.getValue().owner() == owner);
    }

    /** Bir komut adinin (onundeki "/" olmadan) EmbPurpurium'a kayitli olup olmadigini soyler. */
    public boolean isRegistered(String name) {
        if (name == null) return false;
        return commands.containsKey(name.toLowerCase(Locale.ROOT));
    }

    /** Geriye donuk uyumluluk: konsoldan gelen girdi icin varsayilan gonderici ile calistirir. */
    public boolean dispatch(String input) {
        return dispatch(ConsoleCommandSender.INSTANCE, input);
    }

    /** Belirtilen gonderici (konsol veya oyuncu) adina bir komut calistirir. */
    public boolean dispatch(CommandSender sender, String input) {
        String trimmed = input.trim();
        if (trimmed.startsWith("/")) trimmed = trimmed.substring(1);
        if (trimmed.isEmpty()) return false;
        String[] parts = trimmed.split("\\s+");
        String name = parts[0].toLowerCase(Locale.ROOT);
        String[] args = Arrays.copyOfRange(parts, 1, parts.length);
        CommandEntry entry = commands.get(name);
        if (entry == null) return false;
        try {
            boolean success = entry.command().execute(sender, args);
            if (!success) sender.sendMessage(EmbLogger.YELLOW + "Usage: " + entry.command().getUsage() + EmbLogger.RESET);
        } catch (Exception e) {
            logger.error("Exception executing /" + name, e);
            sender.sendMessage(EmbLogger.RED + "An error occurred running /" + name + EmbLogger.RESET);
        }
        return true;
    }

    public Map<String, CommandEntry> getCommands() { return Collections.unmodifiableMap(commands); }
    public record CommandEntry(Command command, Object owner) {}
}
