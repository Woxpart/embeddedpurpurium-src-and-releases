package net.embpurpurium.api.event;

public class PlayerLeaveEvent extends Event {
    private final String playerName;
    private String leaveMessage;

    public PlayerLeaveEvent(String playerName) {
        this.playerName = playerName;
        this.leaveMessage = playerName + " left the game";
    }
    public String getPlayerName() { return playerName; }
    public String getLeaveMessage() { return leaveMessage; }
    public void setLeaveMessage(String leaveMessage) { this.leaveMessage = leaveMessage; }
}
