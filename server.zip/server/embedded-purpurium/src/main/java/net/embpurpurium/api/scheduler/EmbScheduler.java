package net.embpurpurium.api.scheduler;

import net.embpurpurium.console.EmbLogger;
import net.embpurpurium.plugin.JavaPlugin;

import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

public class EmbScheduler {
    private static final EmbLogger logger = new EmbLogger("Scheduler");
    private static final AtomicInteger taskIdCounter = new AtomicInteger(0);

    private final ScheduledExecutorService executor = Executors.newScheduledThreadPool(4, r -> {
        Thread t = new Thread(r, "EmbPurpurium-Scheduler-" + taskIdCounter.incrementAndGet());
        t.setDaemon(true);
        return t;
    });

    public ScheduledTask runLater(JavaPlugin owner, Runnable task, long delay, TimeUnit unit) {
        int id = taskIdCounter.incrementAndGet();
        ScheduledFuture<?> future = executor.schedule(wrap(owner, task, id), delay, unit);
        return new ScheduledTask(id, owner, future, false);
    }

    public ScheduledTask runRepeating(JavaPlugin owner, Runnable task, long initialDelay, long period, TimeUnit unit) {
        int id = taskIdCounter.incrementAndGet();
        ScheduledFuture<?> future = executor.scheduleAtFixedRate(wrap(owner, task, id), initialDelay, period, unit);
        return new ScheduledTask(id, owner, future, true);
    }

    public void cancelAll(JavaPlugin owner) {
        logger.debug("cancelAll() called for " + owner.getDescription().getName() + " — individual task cancellation recommended.");
    }

    public void shutdown() {
        executor.shutdownNow();
        logger.debug("Scheduler shut down.");
    }

    private Runnable wrap(JavaPlugin owner, Runnable task, int id) {
        return () -> {
            try { task.run(); }
            catch (Exception e) { logger.error("[Task#" + id + " in " + owner.getDescription().getName() + "] Unhandled exception", e); }
        };
    }
}
