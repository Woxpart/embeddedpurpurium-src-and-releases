package net.embpurpurium.api.command;

public interface Command {

    /** Geriye donuk uyumluluk icin korunan orijinal metod (sadece console'dan cagrilirken kullanilir). */
    boolean execute(String[] args);

    /**
     * Sender-farkinda calistirma. Varsayilan olarak eski execute(String[]) metoduna
     * yonlendirir, boylece mevcut .embplugin'ler hicbir degisiklik yapmadan calismaya devam eder.
     * Oyuncudan gelen komutlara duzgun yanit verebilmek isteyen komutlar bu metodu override edebilir.
     */
    default boolean execute(CommandSender sender, String[] args) {
        return execute(args);
    }

    String getDescription();
    String getUsage();
}
