package net.embpurpurium.plugin;

import net.embpurpurium.api.command.Command;
import net.embpurpurium.api.event.Listener;
import net.embpurpurium.api.scheduler.EmbScheduler;
import net.embpurpurium.console.EmbLogger;

import java.io.*;

public abstract class JavaPlugin {
    private PluginDescription description;
    private PluginManager pluginManager;
    private EmbLogger logger;
    private File dataFolder;

    public void onEnable() {}
    public void onDisable() {}

    protected void registerEvents(Listener listener) {
        pluginManager.getEventBus().registerListener(listener, this);
    }

    protected void registerCommand(String name, Command command) {
        pluginManager.getCommandManager().registerCommand(name, command, this);
    }

    public File getDataFolder() {
        if (!dataFolder.exists()) dataFolder.mkdirs();
        return dataFolder;
    }

    protected void saveDefaultResource(String resourceName, boolean replace) {
        File dest = new File(getDataFolder(), resourceName);
        if (dest.exists() && !replace) return;
        try (InputStream is = getClass().getClassLoader().getResourceAsStream(resourceName)) {
            if (is == null) {
                logger.warn("Resource not found in plugin JAR: " + resourceName);
                return;
            }
            try (FileOutputStream fos = new FileOutputStream(dest)) {
                is.transferTo(fos);
                logger.debug("Saved resource: " + resourceName);
            }
        } catch (IOException e) {
            logger.error("Failed to save resource " + resourceName, e);
        }
    }

    public EmbScheduler getScheduler() {
        return pluginManager.getScheduler();
    }

    public PluginDescription getDescription() { return description; }
    public void setDescription(PluginDescription description) {
        this.description = description;
        this.logger = new EmbLogger(description.getName());
    }
    public PluginManager getPluginManager() { return pluginManager; }
    public void setPluginManager(PluginManager pluginManager) {
        this.pluginManager = pluginManager;
        if (description != null) this.dataFolder = new File("plugins/" + description.getName());
    }
    public EmbLogger getLogger() { return logger; }

    @Override
    public String toString() {
        return description != null ? description.toString() : getClass().getSimpleName();
    }
}
