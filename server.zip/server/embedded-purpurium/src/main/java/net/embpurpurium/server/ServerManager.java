package net.embpurpurium.server;

import net.embpurpurium.EmbeddedPurpurium;
import net.embpurpurium.api.command.CommandSender;
import net.embpurpurium.api.command.ConsoleCommandSender;
import net.embpurpurium.api.command.PlayerCommandSender;
import net.embpurpurium.api.event.*;
import net.embpurpurium.config.EmbConfig;
import net.embpurpurium.console.EmbLogger;

import java.io.*;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.*;

public class ServerManager {

    private final EmbeddedPurpurium server;
    private final EmbLogger logger = new EmbLogger("ServerManager");
    private final File serverJar;
    private final EmbConfig config;
    private final PlayerTracker playerTracker;

    private Process process;
    private PrintWriter stdin;
    private final AtomicBoolean running = new AtomicBoolean(false);
    private long startTime;

    // Genel pattern'ler - farkli log formatlarini yakalar
    // 1.13.2 - 1.21.4 arasi [thread/INFO]: mesaj formati tutarli
    private static final Pattern JOIN_PATTERN =
            Pattern.compile(".*INFO.*: (\\S+) joined the game");
    private static final Pattern LEAVE_PATTERN =
            Pattern.compile(".*INFO.*: (\\S+) left the game");
    private static final Pattern CHAT_PATTERN =
            Pattern.compile(".*INFO.*: <(\\S+)> (.+)$");
    private static final Pattern DONE_PATTERN =
            Pattern.compile(".*INFO.*: Done \\((.+?)\\)!");
    // Bir oyuncu oyun icinden slash komut yazdiginda vanilla sunucu bunu her zaman loglar
    // (komut vanilla'ya bilinmese, yani bizim /embhelp gibi eklenti komutlarimiz olsa bile).
    // Bu satiri yakalayip EmbPurpurium'un kendi komutlarini oyuncu adina calistirmak icin kullaniyoruz.
    private static final Pattern PLAYER_COMMAND_PATTERN =
            Pattern.compile(".*INFO.*: (\\S+) issued server command: /?(\\S+)(.*)$");
    // Olum mesajlari - genisletilmis
    private static final Pattern DEATH_PATTERN =
            Pattern.compile(".*INFO.*: (\\S+) (was (?:slain|killed|shot|blown up|fireballed|pummeled|squashed|squished|tried to swim|walked into|didn't want to|starved|suffocated|fell|hit the ground|went up in flames|burned|drowned|froze|was impaled|was skewered|was poked|was stung|experienced kinetic energy|was doomed|was squashed|was pricked|was killed).+|drowned|fell .+|was struck by lightning.*|blew up|walked into a cactus|died|starved to death|suffocated|withered|discovered.*was fatal.*)$");

    public ServerManager(EmbeddedPurpurium server, File serverJar, EmbConfig config) {
        this.server        = server;
        this.serverJar     = serverJar;
        this.config        = config;
        this.playerTracker = new PlayerTracker();
    }

    public void start() throws IOException {
        acceptEula();

        List<String> command = buildCommand();
        logger.info("Launching: " + String.join(" ", command));

        ProcessBuilder pb = new ProcessBuilder(command);
        pb.directory(serverJar.getParentFile());
        pb.redirectErrorStream(true);

        process   = pb.start();
        startTime = Instant.now().getEpochSecond();
        running.set(true);

        stdin = new PrintWriter(
                new BufferedWriter(new OutputStreamWriter(process.getOutputStream())), true);

        Thread reader = new Thread(this::readStdout, "EmbPurpurium-StdoutReader");
        reader.setDaemon(true);
        reader.start();

        Thread watcher = new Thread(this::watchProcess, "EmbPurpurium-ProcessWatcher");
        watcher.setDaemon(true);
        watcher.start();

        Runtime.getRuntime().addShutdownHook(new Thread(this::stop, "EmbPurpurium-Shutdown"));
    }

    /** Konsoldan gelen komutlar icin - eskisi gibi davranir (ConsoleCommandSender kullanir). */
    public void sendCommand(String command) {
        if (command == null || command.isBlank()) return;

        ConsoleCommandEvent event = server.getPluginManager().getEventBus()
                .fire(new ConsoleCommandEvent(command));
        if (event.isCancelled()) return;

        boolean handled = server.getPluginManager().getCommandManager()
                .dispatch(ConsoleCommandSender.INSTANCE, event.getCommand());

        if (!handled && stdin != null) {
            stdin.println(event.getCommand());
        }
    }

    /**
     * Vanilla sunucu stdin'ine dogrudan, CommandManager'dan gecirmeden bir satir yazar.
     * PlayerCommandSender, oyuncuya "tellraw" ile geri bildirim gondermek icin bunu kullanir.
     */
    public void sendRaw(String rawCommand) {
        if (rawCommand == null || rawCommand.isBlank()) return;
        if (stdin != null) stdin.println(rawCommand);
    }

    public void stop() {
        if (!running.get()) return;
        logger.info("Sending stop signal to vanilla server...");
        server.getPluginManager().getEventBus().fire(new ServerStopEvent());
        if (stdin != null) stdin.println("stop");
        running.set(false);
    }

    public boolean isRunning()         { return running.get() && (process == null || process.isAlive()); }
    public PlayerTracker getPlayerTracker() { return playerTracker; }
    public long getStartTime()         { return startTime; }

    public long getUptimeSeconds() {
        return startTime > 0 ? Instant.now().getEpochSecond() - startTime : 0;
    }

    public String getUptimeFormatted() {
        long s = getUptimeSeconds();
        long h = s / 3600, m = (s % 3600) / 60, sec = s % 60;
        if (h > 0) return h + "h " + m + "m " + sec + "s";
        if (m > 0) return m + "m " + sec + "s";
        return sec + "s";
    }

    private List<String> buildCommand() {
        List<String> cmd = new ArrayList<>();
        cmd.add("java");
        cmd.add("-Xms" + config.minMemory());
        cmd.add("-Xmx" + config.maxMemory());

        String extra = config.extraArgs().trim();
        if (!extra.isEmpty()) {
            for (String arg : extra.split("\\s+")) {
                if (!arg.isBlank()) cmd.add(arg);
            }
        }

        cmd.add("-jar");
        cmd.add(serverJar.getName());
        cmd.add("nogui");
        return cmd;
    }

    private void acceptEula() {
        File eula = new File(serverJar.getParentFile(), "eula.txt");
        if (!eula.exists()) {
            try (PrintWriter pw = new PrintWriter(new FileWriter(eula))) {
                pw.println("# Auto-accepted by Embedded Purpurium");
                pw.println("# https://aka.ms/MinecraftEULA");
                pw.println("eula=true");
                logger.info("EULA auto-accepted (.server/eula.txt created).");
            } catch (IOException e) {
                logger.error("Could not write eula.txt", e);
            }
        }
    }

    private void readStdout() {
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(process.getInputStream()))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (config.showServerOutput()) EmbLogger.serverLine(line);
                parseLine(line);
            }
        } catch (IOException e) {
            if (running.get()) logger.error("Error reading server stdout", e);
        }
    }

    private void parseLine(String line) {
        EventBus bus = server.getPluginManager().getEventBus();
        Matcher m;

        m = JOIN_PATTERN.matcher(line);
        if (m.find()) {
            String name = m.group(1);
            playerTracker.onPlayerJoin(name);
            bus.fire(new PlayerJoinEvent(name));
            return;
        }

        m = LEAVE_PATTERN.matcher(line);
        if (m.find()) {
            String name = m.group(1);
            playerTracker.onPlayerLeave(name);
            bus.fire(new PlayerLeaveEvent(name));
            return;
        }

        m = PLAYER_COMMAND_PATTERN.matcher(line);
        if (m.find()) {
            String player  = m.group(1);
            String cmdName = m.group(2);
            String rest    = m.group(3) == null ? "" : m.group(3).trim();
            handlePlayerCommand(player, cmdName, rest);
            return;
        }

        m = CHAT_PATTERN.matcher(line);
        if (m.find()) {
            bus.fire(new PlayerChatEvent(m.group(1), m.group(2)));
            return;
        }

        m = DONE_PATTERN.matcher(line);
        if (m.find()) {
            logger.success(EmbLogger.BOLD + "Server is READY" + EmbLogger.RESET
                    + EmbLogger.GREEN + " (started in " + m.group(1) + ")"
                    + EmbLogger.GRAY + " - type /embhelp for plugin commands");
            bus.fire(new ServerStartEvent(m.group(1)));
            return;
        }

        m = DEATH_PATTERN.matcher(line);
        if (m.find()) {
            bus.fire(new PlayerDeathEvent(m.group(1), m.group(1) + " " + m.group(2)));
        }
    }

    /**
     * Bir oyuncu oyun icinde /embhelp gibi bir EmbPurpurium komutu yazdiginda calisir.
     * Sadece bizim CommandManager'a KAYITLI komutlari isliyoruz - vanilla'nin kendi
     * komutlarina (/gamemode, /give vb.) hicbir sekilde karismiyoruz, onlari vanilla
     * zaten kendi isliyor. Not: Vanilla sunucu, bilmedigi /embhelp gibi bir komut icin
     * oyuncuya kendi "Unknown command" mesajini da gonderir - buna bizim tarafimizdan
     * mudahale etmek mumkun degil (surece disaridan bagli, kaynagi degistirmiyoruz);
     * EmbPurpurium'un asil ciktisi hemen ardindan ayni sohbette gorunecektir.
     */
    private void handlePlayerCommand(String player, String cmdName, String rest) {
        String name = cmdName.toLowerCase(Locale.ROOT);
        if (!server.getPluginManager().getCommandManager().isRegistered(name)) return;

        String full = "/" + cmdName + (rest.isEmpty() ? "" : " " + rest);
        CommandSender sender = new PlayerCommandSender(player, this);
        server.getPluginManager().getCommandManager().dispatch(sender, full);
    }

    private void watchProcess() {
        try {
            int code = process.waitFor();
            running.set(false);
            playerTracker.clear();
            if (code == 0) logger.success("Vanilla server exited cleanly (code 0).");
            else           logger.warn("Vanilla server exited with code " + code);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
