package net.embpurpurium.api.event;

public class ServerStartEvent extends Event {
    private final String startupTime;

    public ServerStartEvent(String startupTime) { this.startupTime = startupTime; }
    public String getStartupTime() { return startupTime; }
}
