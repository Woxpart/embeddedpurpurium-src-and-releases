package net.embpurpurium.plugin;

import net.embpurpurium.EmbeddedPurpurium;
import net.embpurpurium.api.command.Command;
import net.embpurpurium.api.command.CommandManager;
import net.embpurpurium.api.command.CommandSender;
import net.embpurpurium.api.command.ConsoleCommandSender;
import net.embpurpurium.api.event.EventBus;
import net.embpurpurium.api.scheduler.EmbScheduler;
import net.embpurpurium.console.EmbLogger;

import java.io.File;
import java.util.*;

public class PluginManager {
    private final EmbLogger logger = new EmbLogger("PluginManager");
    private final EmbeddedPurpurium server;
    private final EventBus eventBus = new EventBus();
    private final CommandManager commandManager = new CommandManager();
    private final EmbScheduler scheduler = new EmbScheduler();
    private final PluginLoader loader = new PluginLoader();
    private final List<JavaPlugin> plugins = new ArrayList<>();
    private final Map<String, File> pluginFiles = new LinkedHashMap<>();
    private File pluginsDir;

    public PluginManager(EmbeddedPurpurium server) {
        this.server = server;
        registerBuiltinCommands();
    }

    public void loadPlugins(File dir) {
        this.pluginsDir = dir;
        File[] files = dir.listFiles(f -> f.getName().endsWith(".embplugin"));
        if (files == null || files.length == 0) {
            logger.info("No .embplugin files found in " + dir.getPath() + " - drop plugins there and restart.");
            return;
        }
        Arrays.sort(files, Comparator.comparing(File::getName));
        logger.info("Found " + files.length + " plugin file(s)...");
        for (File f : files) {
            JavaPlugin plugin = loader.load(f, this);
            if (plugin != null) {
                pluginFiles.put(plugin.getDescription().getName(), f);
                enablePlugin(plugin);
            }
        }
        EmbLogger.separator();
        logger.success(plugins.size() + " plugin(s) enabled.");
        EmbLogger.separator();
    }

    public void enablePlugin(JavaPlugin plugin) {
        try {
            plugin.onEnable();
            plugins.add(plugin);
            EmbLogger.tickRow(plugin.getDescription().getName()
                    + " " + EmbLogger.GRAY + "v" + plugin.getDescription().getVersion()
                    + " by " + plugin.getDescription().getAuthor());
        } catch (Exception e) {
            logger.error("Failed to enable " + plugin.getDescription().getName(), e);
        }
    }

    public void disablePlugin(JavaPlugin plugin) {
        try { plugin.onDisable(); }
        catch (Exception e) { logger.error("Error disabling " + plugin.getDescription().getName(), e); }
        eventBus.unregisterAll(plugin);
        commandManager.unregisterAll(plugin);
        plugins.remove(plugin);
        pluginFiles.remove(plugin.getDescription().getName());
        logger.info("Disabled: " + plugin.getDescription().getName());
    }

    public void disableAll() {
        EmbLogger.separator();
        logger.info("Disabling all plugins...");
        List<JavaPlugin> reversed = new ArrayList<>(plugins);
        Collections.reverse(reversed);
        reversed.forEach(this::disablePlugin);
        scheduler.shutdown();
    }

    public void reloadAll() {
        EmbLogger.section("Hot Reload");
        logger.info("Reloading all plugins...");
        List<JavaPlugin> old = new ArrayList<>(plugins);
        Collections.reverse(old);
        for (JavaPlugin p : old) {
            try { p.onDisable(); } catch (Exception ignored) {}
            eventBus.unregisterAll(p);
            commandManager.unregisterAll(p);
        }
        plugins.clear();
        if (pluginsDir != null) {
            File[] files = pluginsDir.listFiles(f -> f.getName().endsWith(".embplugin"));
            if (files != null) {
                Arrays.sort(files, Comparator.comparing(File::getName));
                for (File f : files) {
                    JavaPlugin p = loader.load(f, this);
                    if (p != null) {
                        pluginFiles.put(p.getDescription().getName(), f);
                        enablePlugin(p);
                    }
                }
            }
        }
        logger.success("Reload complete - " + plugins.size() + " plugin(s) active.");
    }

    private void registerBuiltinCommands() {
        commandManager.registerCommand("embhelp", new Command() {
            @Override public boolean execute(String[] args) { return execute(ConsoleCommandSender.INSTANCE, args); }
            @Override public boolean execute(CommandSender sender, String[] args) {
                StringBuilder sb = new StringBuilder(EmbLogger.sectionText("EmbPurpurium Commands"));
                for (var e : commandManager.getCommands().entrySet()) {
                    sb.append('\n').append(EmbLogger.CYAN).append("  /").append(e.getKey()).append(EmbLogger.RESET)
                      .append(EmbLogger.GRAY).append(" - ").append(EmbLogger.RESET)
                      .append(e.getValue().command().getDescription())
                      .append(EmbLogger.GRAY).append("  (").append(e.getValue().command().getUsage()).append(")")
                      .append(EmbLogger.RESET);
                }
                sender.sendMessage(sb.toString());
                return true;
            }
            @Override public String getDescription() { return "Lists all EmbPurpurium plugin commands"; }
            @Override public String getUsage()       { return "/embhelp"; }
        }, this);

        commandManager.registerCommand("embplugins", new Command() {
            @Override public boolean execute(String[] args) { return execute(ConsoleCommandSender.INSTANCE, args); }
            @Override public boolean execute(CommandSender sender, String[] args) {
                StringBuilder sb = new StringBuilder(EmbLogger.sectionText("Loaded Plugins (" + plugins.size() + ")"));
                if (plugins.isEmpty()) {
                    sb.append('\n').append(EmbLogger.warnRowText("No plugins loaded."));
                } else {
                    for (JavaPlugin p : plugins) {
                        PluginDescription d = p.getDescription();
                        sb.append('\n').append(EmbLogger.GREEN).append("  \u25CF ").append(EmbLogger.BOLD).append(d.getName())
                          .append(EmbLogger.RESET).append(EmbLogger.GRAY).append("  v").append(d.getVersion())
                          .append("  by ").append(d.getAuthor())
                          .append(d.getDescription() != null ? "  -  " + d.getDescription() : "")
                          .append(EmbLogger.RESET);
                    }
                }
                sender.sendMessage(sb.toString());
                return true;
            }
            @Override public String getDescription() { return "Lists all loaded .embplugin plugins"; }
            @Override public String getUsage()       { return "/embplugins"; }
        }, this);

        commandManager.registerCommand("embstatus", new Command() {
            @Override public boolean execute(String[] args) { return execute(ConsoleCommandSender.INSTANCE, args); }
            @Override public boolean execute(CommandSender sender, String[] args) {
                StringBuilder sb = new StringBuilder(EmbLogger.sectionText("Server Status"));
                var sm = server.getServerManager();
                String mcVersion = server.getConfig().serverVersion();
                if (sm != null) {
                    sb.append('\n').append(EmbLogger.statusRowText("Uptime", sm.getUptimeFormatted()));
                    sb.append('\n').append(EmbLogger.statusRowText("Players Online", sm.getPlayerTracker().getOnlineCount() + ""
                            + EmbLogger.GRAY + " (peak: " + sm.getPlayerTracker().getPeakCount() + ")"));
                    sb.append('\n').append(EmbLogger.statusRowText("Total Joins", sm.getPlayerTracker().getTotalJoins() + ""));
                    Set<String> online = sm.getPlayerTracker().getOnlinePlayers();
                    if (!online.isEmpty()) {
                        sb.append('\n').append(EmbLogger.statusRowText("Online Players",
                                EmbLogger.GREEN + String.join(", ", online) + EmbLogger.RESET));
                    }
                } else {
                    sb.append('\n').append(EmbLogger.warnRowText("Server not yet started."));
                }
                sb.append('\n').append(EmbLogger.statusRowText("Loaded Plugins", plugins.size() + ""));
                sb.append('\n').append(EmbLogger.statusRowText("Version", "Embedded Purpurium v1.0.0 (MC " + mcVersion + ")"));
                sender.sendMessage(sb.toString());
                return true;
            }
            @Override public String getDescription() { return "Displays server status and stats"; }
            @Override public String getUsage()       { return "/embstatus"; }
        }, this);

        commandManager.registerCommand("embreload", new Command() {
            @Override public boolean execute(String[] args) { return execute(ConsoleCommandSender.INSTANCE, args); }
            @Override public boolean execute(CommandSender sender, String[] args) {
                reloadAll();
                sender.sendMessage(EmbLogger.GREEN + "Reload complete - " + plugins.size() + " plugin(s) active." + EmbLogger.RESET);
                return true;
            }
            @Override public String getDescription() { return "Hot-reloads all .embplugin files"; }
            @Override public String getUsage()       { return "/embreload"; }
        }, this);

        commandManager.registerCommand("embplayers", new Command() {
            @Override public boolean execute(String[] args) { return execute(ConsoleCommandSender.INSTANCE, args); }
            @Override public boolean execute(CommandSender sender, String[] args) {
                var sm = server.getServerManager();
                if (sm == null) { sender.sendMessage(EmbLogger.YELLOW + "Server not running." + EmbLogger.RESET); return true; }
                Set<String> online = sm.getPlayerTracker().getOnlinePlayers();
                StringBuilder sb = new StringBuilder(EmbLogger.sectionText("Online Players (" + online.size() + ")"));
                if (online.isEmpty()) {
                    sb.append('\n').append(EmbLogger.warnRowText("No players online."));
                } else {
                    for (String name : online) {
                        long dur = sm.getPlayerTracker().getSessionDuration(name);
                        long m = dur / 60, s = dur % 60;
                        sb.append('\n').append(EmbLogger.statusRowText(name, m + "m " + s + "s"));
                    }
                }
                sender.sendMessage(sb.toString());
                return true;
            }
            @Override public String getDescription() { return "Lists online players and session durations"; }
            @Override public String getUsage()       { return "/embplayers"; }
        }, this);
    }

    public EventBus getEventBus()             { return eventBus; }
    public CommandManager getCommandManager() { return commandManager; }
    public EmbScheduler getScheduler()        { return scheduler; }
    public List<JavaPlugin> getPlugins()      { return Collections.unmodifiableList(plugins); }
    public EmbeddedPurpurium getServer()      { return server; }
}
