package net.embpurpurium.console;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class EmbLogger {
    public static final String RESET     = "\u001B[0m";
    public static final String BOLD      = "\u001B[1m";
    public static final String DIM       = "\u001B[2m";
    public static final String ITALIC    = "\u001B[3m";
    public static final String UNDERLINE = "\u001B[4m";
    public static final String BLACK   = "\u001B[30m";
    public static final String RED     = "\u001B[31m";
    public static final String GREEN   = "\u001B[32m";
    public static final String YELLOW  = "\u001B[33m";
    public static final String BLUE    = "\u001B[34m";
    public static final String PURPLE  = "\u001B[35m";
    public static final String CYAN    = "\u001B[36m";
    public static final String WHITE   = "\u001B[37m";
    public static final String GRAY    = "\u001B[90m";
    public static final String BG_PURPLE = "\u001B[45m";
    public static final String BG_CYAN   = "\u001B[46m";
    public static final String BG_BLACK  = "\u001B[40m";

    public static final String TL = "\u2554", TR = "\u2557", BL = "\u255A", BR = "\u255D";
    public static final String H  = "\u2550", V  = "\u2551";
    private static final String ML = "\u2560", MR = "\u2563";
    private static final DateTimeFormatter TIME_FMT = DateTimeFormatter.ofPattern("HH:mm:ss");
    private final String name;

    public EmbLogger(String name) { this.name = name; }

    private String timestamp() { return GRAY + DIM + "[" + LocalTime.now().format(TIME_FMT) + "]" + RESET; }
    private String prefix(String level, String levelColor, String nameColor) {
        return timestamp() + " " + levelColor + BOLD + "[" + level + "]" + RESET + " " + nameColor + BOLD + "[" + name + "]" + RESET + " ";
    }

    public void info(String message) { System.out.println(prefix("INFO", CYAN, PURPLE) + WHITE + message + RESET); }
    public void warn(String message) { System.out.println(prefix("WARN", YELLOW + BOLD, PURPLE) + YELLOW + message + RESET); }
    public void error(String message) { System.err.println(prefix("ERROR", RED + BOLD, PURPLE) + RED + message + RESET); }
    public void error(String message, Throwable t) { error(message + " -> " + t.getClass().getSimpleName() + ": " + t.getMessage()); }
    public void success(String message) { System.out.println(prefix("OK", GREEN + BOLD, PURPLE) + GREEN + message + RESET); }
    public void debug(String message) { System.out.println(prefix("DEBUG", GRAY, GRAY) + GRAY + DIM + message + RESET); }

    public static void separator() { System.out.println(GRAY + DIM + "  " + H.repeat(54) + RESET); }

    public static void section(String title) { System.out.println(sectionText(title)); }

    /** section() ile ayni gorseli uretir ama basmak yerine String olarak dondurur (ör. oyuncuya tellraw ile gondermek icin). */
    public static String sectionText(String title) {
        int width = Math.max(title.length() + 6, 36);
        String bar = H.repeat(width);
        StringBuilder sb = new StringBuilder();
        sb.append('\n');
        sb.append(PURPLE).append("  ").append(TL).append(bar).append(TR).append(RESET).append('\n');
        int paddingLen = width - 2 - stripAnsi(title).length() - 2;
        String padding = " ".repeat(Math.max(0, paddingLen));
        sb.append(PURPLE).append("  ").append(V).append(RESET).append("  ")
          .append(CYAN).append(BOLD).append("\u25CF ").append(WHITE).append(title).append(RESET)
          .append(padding).append(PURPLE).append("  ").append(V).append(RESET).append('\n');
        sb.append(PURPLE).append("  ").append(BL).append(bar).append(BR).append(RESET);
        return sb.toString();
    }

    public static void statusRow(String label, String value) { System.out.println(statusRowText(label, value)); }

    public static String statusRowText(String label, String value) {
        String lbl = GRAY + DIM + "  " + RESET + CYAN + "\u25CF " + WHITE + label;
        int pad = 28 - stripAnsi(label).length();
        return lbl + " ".repeat(Math.max(1, pad)) + YELLOW + value + RESET;
    }

    public static void tickRow(String label) { System.out.println(tickRowText(label)); }
    public static String tickRowText(String label) { return "  " + GREEN + BOLD + "\u2714 " + RESET + WHITE + label + RESET; }

    public static void warnRow(String label) { System.out.println(warnRowText(label)); }
    public static String warnRowText(String label) { return "  " + YELLOW + BOLD + "\u26A0 " + RESET + YELLOW + label + RESET; }

    public static void serverLine(String line) { System.out.println(GRAY + DIM + "  [SERVER] " + RESET + GRAY + line + RESET); }

    public static String stripAnsi(String s) {
        return s == null ? "" : s.replaceAll("\u001B\\[[0-9;]*[a-zA-Z]", "");
    }

    /**
     * s'i, ANSI kodlarini saymadan (gorunen uzunluga gore), sag tarafa bosluklarla
     * hedef genislige tamamlar. Zaten hedeften genisse oldugu gibi dondurulur.
     * Banner/kutu cizimlerinde satirlarin kenarlarinin daima hizali kalmasini garanti eder.
     */
    public static String padVisible(String s, int width) {
        int visible = stripAnsi(s).length();
        if (visible >= width) return s;
        return s + " ".repeat(width - visible);
    }

    public String getName() { return name; }
}
