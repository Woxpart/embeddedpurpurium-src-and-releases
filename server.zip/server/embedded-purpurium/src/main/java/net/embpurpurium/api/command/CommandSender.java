package net.embpurpurium.api.command;

/**
 * Bir komutu kimin calistirdigini temsil eder: konsol ya da oyun ici bir oyuncu.
 * Command implementasyonlari geri bildirimi System.out yerine bu arayuz uzerinden
 * gondermelidir, boylece hem konsolda hem de oyuncunun sohbetinde dogru sekilde gorunur.
 */
public interface CommandSender {

    /** Gonderene mesaj iletir (konsolda satir basar, oyuncuya sohbet mesaji olarak gider). */
    void sendMessage(String message);

    /** "CONSOLE" ya da oyuncunun kullanici adi. */
    String getName();

    /** Gonderen oyun ici bir oyuncuysa true. */
    boolean isPlayer();
}
