package net.embpurpurium.server;

import net.embpurpurium.console.EmbLogger;

import java.time.Instant;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class PlayerTracker {
    private static final EmbLogger logger = new EmbLogger("PlayerTracker");
    private final Map<String, Long> onlinePlayers = new ConcurrentHashMap<>();
    private long peakPlayerCount = 0;
    private long totalJoins = 0;

    public void onPlayerJoin(String name) {
        onlinePlayers.put(name, Instant.now().getEpochSecond());
        totalJoins++;
        if (onlinePlayers.size() > peakPlayerCount) peakPlayerCount = onlinePlayers.size();
        logger.debug("Tracking join: " + name + " (online: " + onlinePlayers.size() + ")");
    }

    public void onPlayerLeave(String name) {
        onlinePlayers.remove(name);
        logger.debug("Tracking leave: " + name + " (online: " + onlinePlayers.size() + ")");
    }

    public Set<String> getOnlinePlayers() {
        return Collections.unmodifiableSet(onlinePlayers.keySet());
    }

    public long getSessionDuration(String name) {
        Long joinTime = onlinePlayers.get(name);
        return joinTime == null ? -1 : Instant.now().getEpochSecond() - joinTime;
    }

    public int getOnlineCount()   { return onlinePlayers.size(); }
    public long getPeakCount()    { return peakPlayerCount; }
    public long getTotalJoins()   { return totalJoins; }
    public boolean isOnline(String name) { return onlinePlayers.containsKey(name); }
    public void clear() { onlinePlayers.clear(); }
}
