package net.embpurpurium;

import net.embpurpurium.config.EmbConfig;
import net.embpurpurium.console.EmbLogger;
import net.embpurpurium.plugin.PluginManager;
import net.embpurpurium.server.ServerDownloader;
import net.embpurpurium.server.ServerManager;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.Scanner;

public class EmbeddedPurpurium {

    private static EmbeddedPurpurium instance;

    private final EmbLogger     logger;
    private final EmbConfig     config;
    private final PluginManager pluginManager;
    private ServerManager       serverManager;

    public EmbeddedPurpurium() {
        instance      = this;
        this.config   = new EmbConfig();
        this.logger   = new EmbLogger("EmbPurpurium");
        this.pluginManager = new PluginManager(this);
    }

    public static EmbeddedPurpurium getInstance() { return instance; }

    public void start() throws Exception {
        printBanner();

        String mcVersion = config.serverVersion();
        logger.info("Target Minecraft version: " + EmbLogger.YELLOW + mcVersion + EmbLogger.RESET);

        // Sunucu dosyalarini gizli .server/ klasorunde tut
        File serverDir = new File(".server");
        if (!serverDir.exists()) {
            serverDir.mkdirs();
            hideDirectory(serverDir);
        }

        File serverJar       = new File(serverDir, "server.jar");
        File versionMarker   = new File(serverDir, ".version");
        String installedVer  = readInstalledVersion(versionMarker);

        if (serverJar.exists() && (installedVer == null || !installedVer.equals(mcVersion))) {
            // Config'teki surum, daha once indirilmis olan surumden farkli (ya da bilinmiyor).
            // Eski .server/ klasorunu tamamen silip dogru surumu yeniden indirecegiz.
            if (installedVer != null) {
                logger.warn("Configured version (" + mcVersion + ") differs from the installed version ("
                        + installedVer + ") - removing old .server/ and downloading " + mcVersion + "...");
            } else {
                logger.warn("Could not verify the installed server version in .server/ - re-downloading "
                        + mcVersion + " to be safe...");
            }
            deleteDirectory(serverDir);
            serverDir.mkdirs();
            hideDirectory(serverDir);
        }

        if (!serverJar.exists()) {
            logger.info("Vanilla " + mcVersion + " server not found in .server/ - downloading...");
            new ServerDownloader(mcVersion).download(serverJar);
            writeInstalledVersion(versionMarker, mcVersion);
        } else {
            EmbLogger.tickRow("Vanilla server found: " + serverJar.getAbsolutePath());
        }

        File pluginsDir = new File("plugins");
        if (!pluginsDir.exists()) {
            pluginsDir.mkdirs();
            logger.info("Created plugins/ - drop .embplugin files here.");
        }

        EmbLogger.section("Plugin Loading");
        pluginManager.loadPlugins(pluginsDir);

        EmbLogger.section("Starting Vanilla Server");
        serverManager = new ServerManager(this, serverJar, config);
        serverManager.start();

        printConsoleHelp();

        Scanner scanner = new Scanner(System.in);
        while (serverManager.isRunning()) {
            if (scanner.hasNextLine()) {
                String line = scanner.nextLine().trim();
                if (!line.isEmpty()) serverManager.sendCommand(line);
            }
            Thread.sleep(50);
        }

        EmbLogger.separator();
        pluginManager.disableAll();
        logger.success("Embedded Purpurium stopped. Goodbye!");
        EmbLogger.separator();
    }

    private void hideDirectory(File dir) {
        try {
            Files.setAttribute(dir.toPath(), "dos:hidden", true);
        } catch (Exception ignored) {
            // Windows disinda (Linux/macOS) dos:hidden ozniteligi desteklenmez, sorun degil.
        }
    }

    private String readInstalledVersion(File marker) {
        if (!marker.exists()) return null;
        try {
            String v = Files.readString(marker.toPath(), StandardCharsets.UTF_8).trim();
            return v.isEmpty() ? null : v;
        } catch (IOException e) {
            return null;
        }
    }

    private void writeInstalledVersion(File marker, String version) {
        try {
            Files.writeString(marker.toPath(), version, StandardCharsets.UTF_8);
        } catch (IOException e) {
            logger.warn("Could not write .server/.version marker: " + e.getMessage());
        }
    }

    private void deleteDirectory(File dir) {
        File[] files = dir.listFiles();
        if (files != null) {
            for (File f : files) {
                if (f.isDirectory()) deleteDirectory(f);
                else f.delete();
            }
        }
        dir.delete();
    }

    private void printBanner() {
        String mcVersion = config.serverVersion();
        final String P = EmbLogger.PURPLE, C = EmbLogger.CYAN;
        final String G = EmbLogger.GRAY,   R = EmbLogger.RESET;
        final String B = EmbLogger.BOLD,   Y = EmbLogger.YELLOW;
        final String W = EmbLogger.WHITE;
        final String TL = EmbLogger.TL, TR = EmbLogger.TR, BL = EmbLogger.BL, BR = EmbLogger.BR;
        final String H  = EmbLogger.H,  V  = EmbLogger.V;

        // Kutu icin genislik SABIT ve her satir icerigi bu genisliğe padVisible() ile
        // hizalanir; boylece kenarlar hicbir zaman kayamaz (eski surumdeki bozuk ekran hatasi buydu).
        final int WIDTH = 56;

        String top    = P + B + "  " + TL + H.repeat(WIDTH) + TR + R;
        String bottom = P + B + "  " + BL + H.repeat(WIDTH) + BR + R;

        System.out.println();
        System.out.println(top);
        System.out.println(row(P, B, V, R, WIDTH, ""));
        System.out.println(row(P, B, V, R, WIDTH, "   " + C + B + "EMBEDDED PURPURIUM" + R));
        System.out.println(row(P, B, V, R, WIDTH, "   " + W + "Vanilla Minecraft server wrapper" + R));
        System.out.println(row(P, B, V, R, WIDTH, "   " + G + "MC " + Y + mcVersion + R));
        System.out.println(row(P, B, V, R, WIDTH, "   " + G + "v1.0.0  \u00B7  .embplugin support" + R));
        System.out.println(row(P, B, V, R, WIDTH, ""));
        System.out.println(bottom);
        System.out.println();
        System.out.println(G+"  ---------------------------------------------------------"+R);
        System.out.println(G+"    Type "+R+C+"/embhelp"+R+G+" for plugin commands  -  "+R+C+"/embstatus"+R+G+" for server info"+R);
        System.out.println(G+"  ---------------------------------------------------------"+R);
        System.out.println();
    }

    /** Banner icin tek bir kutu satiri uretir; icerik verilen genislige ANSI-guvenli sekilde tamamlanir. */
    private static String row(String P, String B, String V, String R, int width, String content) {
        return P + B + "  " + V + R + EmbLogger.padVisible(content, width) + P + B + V + R;
    }

    private void printConsoleHelp() {
        final String G = EmbLogger.GRAY, C = EmbLogger.CYAN, R = EmbLogger.RESET;
        System.out.println();
        System.out.println(G + "  EmbPurpurium console ready. Built-in commands:" + R);
        System.out.println(G + "  " + C + "/embhelp" + G + "     List plugin commands" + R);
        System.out.println(G + "  " + C + "/embplugins" + G + "  List loaded plugins" + R);
        System.out.println(G + "  " + C + "/embstatus" + G + "   Server status & stats" + R);
        System.out.println(G + "  " + C + "/embplayers" + G + "  Online players & session times" + R);
        System.out.println(G + "  " + C + "/embreload" + G + "   Hot-reload all plugins" + R);
        System.out.println(G + "  Anything else is forwarded to the vanilla server." + R);
        System.out.println(G + "  These commands also work in-game if you type them in chat." + R);
        System.out.println();
    }

    public static void main(String[] args) throws Exception {
        new EmbeddedPurpurium().start();
    }

    public EmbLogger     getLogger()        { return logger; }
    public EmbConfig     getConfig()        { return config; }
    public PluginManager getPluginManager() { return pluginManager; }
    public ServerManager getServerManager() { return serverManager; }
}
