package net.embpurpurium.api.command;

import net.embpurpurium.console.EmbLogger;
import net.embpurpurium.server.ServerManager;

/**
 * Oyun icinden komut yazan bir oyuncuyu temsil eder. sendMessage() cagrildiginda,
 * mesaj vanilla sunucunun stdin'ine "tellraw <oyuncu> ..." komutu olarak yazilir,
 * boylece oyuncu cikti EmbPurpurium komutlarinin ciktisini kendi sohbetinde gorur.
 */
public class PlayerCommandSender implements CommandSender {

    private final String playerName;
    private final ServerManager serverManager;

    public PlayerCommandSender(String playerName, ServerManager serverManager) {
        this.playerName = playerName;
        this.serverManager = serverManager;
    }

    @Override
    public void sendMessage(String message) {
        if (message == null || message.isEmpty()) return;
        // Cok satirli ciktilari (ör. /embhelp listesi) her satir ayri bir tellraw olarak gonder.
        for (String line : message.split("\n", -1)) {
            String clean = EmbLogger.stripAnsi(line).stripTrailing();
            if (clean.isEmpty()) continue;
            serverManager.sendRaw("tellraw " + playerName + " " + toJsonText(clean));
        }
    }

    @Override
    public String getName() { return playerName; }

    @Override
    public boolean isPlayer() { return true; }

    private String toJsonText(String s) {
        StringBuilder sb = new StringBuilder("{\"text\":\"");
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '"'  -> sb.append("\\\"");
                case '\\' -> sb.append("\\\\");
                case '\n' -> sb.append("\\n");
                default   -> sb.append(c);
            }
        }
        sb.append("\",\"color\":\"gray\"}");
        return sb.toString();
    }
}
