# Embedded Purpurium

**Vanilla Minecraft Sunucu Wrapper** - `.embplugin` destegi ile.

## Ozellikler

- **Coklu Surum Destegi**: Minecraft 1.13.2'den 1.21.4'e kadar tum vanilya surumlerini destekler. Surumu `embpurpurium.properties` dosyasindan degistirebilirsin.
- **Otomatik Indirme**: Mojang CDN'den secili surumun server JAR'ini otomatik indirir (SHA-1 dogrulamali).
- **Gizli Sunucu Klasoru**: Tum sunucu dosyalari (eula.txt, world, logs, vb.) `.server/` gizli klasorunde tutulur. Ana dizin temiz kalir.
- **Plugin Sistemi**: `.embplugin` dosyalarini `plugins/` klasorunden yukler.
  - Event bus (PlayerJoin, PlayerLeave, PlayerChat, PlayerDeath, ServerStart, ServerStop)
  - Konsol komutlari
  - Zamanlanmis gorevler (scheduler)
  - Sicak yeniden yukleme (`/embreload`)
- **Oyuncu Takibi**: Online oyuncular, oturum sureleri, zirve oyuncu sayisi.
- **Renkli Konsol**: ANSI renkli loglar ve zengin formatlama.

## Hizli Baslangic

```bash


# Calistir
java -jar target/embedded-purpurium-1.0.0.jar
```

Ilk calistirmada:
1. `embpurpurium.properties` olusturulur.
2. `.server/` gizli klasoru olusturulur ve vanilya sunucu indirilir.
3. `plugins/` klasoru olusturulur.
4. Sunucu baslatilir.

## Surum Degistirme

`embpurpurium.properties` dosyasini ac:

```properties
# Desteklenen surumler: 1.13.2 - 1.21.4
server.version=1.21.4
```

Surumu degistir, ornegin:
```properties
server.version=1.16.5
```

Sonra `.server/server.jar` dosyasini sil ve yeniden baslat. Yeni surum otomatik indirilecektir.

## Yapilandirma

`embpurpurium.properties`:

```properties
server.version=1.21.4
server.memory.min=512M
server.memory.max=2G
server.extra.args=
console.show.server.output=true
```

## Plugin Gelistirme

### 1. Proje Yapisi

```
MyPlugin/
├── src/
│   └── main/
│       ├── java/
│       │   └── com/
│       │       └── example/
│       │           └── MyPlugin.java
│       └── resources/
│           └── embplugin.json
```

### 2. embplugin.json

```json
{
  "name": "MyPlugin",
  "version": "1.0.0",
  "main": "com.example.MyPlugin",
  "author": "YourName",
  "description": "My first plugin",
  "dependencies": []
}
```

### 3. Ana Sinif

```java
package com.example;

import net.embpurpurium.plugin.JavaPlugin;
import net.embpurpurium.api.event.*;

public class MyPlugin extends JavaPlugin implements Listener {
    @Override
    public void onEnable() {
        getLogger().info("MyPlugin enabled!");
        registerEvents(this);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        getLogger().info(event.getPlayerName() + " joined!");
    }
}
```

### 4. Paketleme

```bash
# Derle ve JAR olustur
javac -cp embedded-purpurium-1.0.0.jar MyPlugin.java
jar cvf MyPlugin.jar -C . .

# .embplugin olarak yeniden adlandir
mv MyPlugin.jar MyPlugin.embplugin
```

Sonra `MyPlugin.embplugin` dosyasini `plugins/` klasorune at.

## Dahili Komutlar

| Komut | Aciklama |
|-------|----------|
| `/embhelp` | Tum plugin komutlarini listele |
| `/embplugins` | Yuklenen pluginleri listele |
| `/embstatus` | Sunucu durumu ve istatistikler |
| `/embplayers` | Online oyuncular ve oturum sureleri |
| `/embreload` | Pluginleri sicak yeniden yukle |

## Klasor Yapisi

```
.
├── .server/              # Gizli - vanilya sunucu dosyalari
│   ├── server.jar
│   ├── eula.txt
│   ├── server.properties
│   ├── world/
│   └── logs/
├── plugins/              # .embplugin dosyalari
├── embpurpurium.properties
└── embedded-purpurium-1.0.0.jar
```

## Lisans

MIT
