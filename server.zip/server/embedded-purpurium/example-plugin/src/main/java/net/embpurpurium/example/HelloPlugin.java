package net.embpurpurium.example;

import net.embpurpurium.api.command.Command;
import net.embpurpurium.api.event.*;
import net.embpurpurium.plugin.JavaPlugin;

public class HelloPlugin extends JavaPlugin implements Listener {

    @Override
    public void onEnable() {
        getLogger().info("HelloPlugin is enabling!");
        registerEvents(this);

        registerCommand("hello", new Command() {
            @Override
            public boolean execute(String[] args) {
                String target = args.length > 0 ? args[0] : "World";
                getLogger().info("Hello, " + target + "!");
                return true;
            }
            @Override public String getDescription() { return "Greets someone"; }
            @Override public String getUsage() { return "/hello [name]"; }
        });

        getLogger().success("HelloPlugin enabled successfully!");
    }

    @Override
    public void onDisable() {
        getLogger().info("HelloPlugin disabled. Goodbye!");
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        getLogger().info("→ " + event.getPlayerName() + " joined the server!");
    }

    @EventHandler
    public void onPlayerLeave(PlayerLeaveEvent event) {
        getLogger().info("← " + event.getPlayerName() + " left the server.");
    }

    @EventHandler
    public void onPlayerChat(PlayerChatEvent event) {
        getLogger().info("[CHAT] " + event.getPlayerName() + ": " + event.getMessage());
    }

    @EventHandler
    public void onServerStart(ServerStartEvent event) {
        getLogger().success("Server is ready! Startup took: " + event.getStartupTime());
    }
}
